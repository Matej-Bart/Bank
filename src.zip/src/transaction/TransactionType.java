package transaction;

public enum TransactionType {
    TRANSFER,
    DEPOSIT,
    WITHDRAWAL
}
